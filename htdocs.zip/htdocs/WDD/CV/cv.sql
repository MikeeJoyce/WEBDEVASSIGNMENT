insert into tbleducation(eduID,eduSchool,eduDegree,eduGrade,eduStartYear,eduEndYear) values (110,'XTZSCHOOL','Hons','A',2017,2018);
insert into tbleducation(eduID,eduSchool,eduDegree,eduGrade,eduStartYear,eduEndYear) values (220,'DIT','Bachelors','C',2009,2012);
insert into tbleducation(eduID,eduSchool,eduDegree,eduGrade,eduStartYear,eduEndYear) values (456,'UCD','Hons','DDD',2013,2016);