r<html>
	<head>
	<link id="123" rel="stylesheet" type="text/css" href="creative.css">
		<title>CV</title>
		
		
	</head>
     <style>
            h4{
                color: black;
                display: none;
                }

            #pics{
                        float: right;
                        display: inline-block;
                    }
         
         .myImage{
             
             float: right;
                        display: inline-block;
         }
         
        
        </style>
	<body>
		
		<div id = "main">
            
            <?php $host = "localhost";
            		$user = "root";
            		$pwd = "";
            		$db = "cv";
            		
            		try{
            			$conn = new PDO("mysql:host=$host;dbname=$db",$user,$pw);
            			
            			$conn->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
            			echo "Connected successfully";
            		}
            		catch(PDOException $e){echo "Connection failed:".$e->getMessage();}
            		
            		$sql = "INSERT INTO tbleducation VALUES()";
            		?>
            
            
			<a href="https://www.dit.ie"><img id ="dit" src ="DIT.png" width = 150px height = 150px ></img></a><br/>
        <div id="pics">
                
            <img id="hadi" src = "Images/elephant.jpg" width = 150px height = 150px></img><br/>
            
                <div class="myImage">
                    <img id="4" src="Images/elephant.jpg"  width = 50px height = 50px onclick="imagChange(4)"/>
                </div>
                <div+ class="myImage">
                    <img id="5" src="Images/elephant2.jpg" width = 50px height = 50px onclick="imagChange(5)"/>
                </div>
                <div class="myImage">
                    <img id="6" src="Images/elephant3.jpg" width = 50px height = 50px onclick="imagChange(6)"/>
                </div>
        </div>
            <p id="time" onmouseover="colorChange()"></</p>
            
            <h2><?php $full = $_GET['fname']." ".$_GET['lname']; echo $full; ?></h2>
			<h1>CURRICULUM VITAE</h1>
			<div class = "content">
            <h3>Cover</h3>
			<p>Ut in elementum, tempor ligula a, luctus libero. 
			Aenean ac porta nunc, vitae pellentesque diam. Praesent in lectus metus. 
			Pellentesque habitant morbi tristique senectus et netus et
			malesuada fames ac turpis egestas. Phasellus condimentum porta lectus, 
			at pellentesque eros auctor non. Maecenas nec velit nec 
			odio dapibus dictum vel at nisi.
			Maecenas id tristique magna, ac hendrerit enim.</p>
			<br>
			<p>
				<strong>Etiam commodo,</strong> lorem id pretium placerat, nibh mi tempor quam, 
				nec placerat ipsum risus vitae turpis. 
				Cras porta est nec nisl sollicitudin, id laoreet neque dapibus.
				Vivamus mattis tempor consequat. 
				Aliquam vitae neque mattis, molestie purus nec, hendrerit ante.
			</p>
            </div>
			<hr>
			<div class = "content">
			<h3>Experience</h3>
				<ol>
				<li>Worked in qwertyy TECH </li>
				<li>Mentor in MICROSOFT</li>
				<li>Intern in SUGMA </li>
				</ol>
            </div>
            <div class = "content">
			<h3>Hobbies</h3>
				<ul>
				<li>Play football</li>
				<li>Workout</li>
				<li>Music procing an dmixing ginginginigngingi</li>
				</ul>
			<hr>
            </div>
            <div class = "content">
			<h3>PAST SCHOOLS</h3>
				<ul>
				<li><a href="https://www.google.com">ABC school</a></li>
				<li><a href="https://www.yahoo.com">XYZ public school</a></li>
				<li><a href="https://www.youtube.com">123 private school</a></li>
				</ul>
                </div>
            <div class = "content">
            <h3>Education Level</h3>
			<table border = 1>
				<tr>
					<th>Education</th>
					<th>Years</th>
					<th>Grades</th>
				</tr>
				<tr>
					<td>middle school</td>
					<td>10</td>
					<td>100%</td>
				</tr>
				<tr>
					<td>High school</td>
					<td>2</td>
					<td>90%</td>
				</tr>
				<tr>
					<td>Undergrad</td>
					<td>3~</td>
					<td>89%~</td>
				</tr>
			</table>
                <p>What is my middle name?</p> 
                <h4 id="1">Parayil</h4>
                <button  onclick="showAnswer(1)" value="1">Answer</button>
                <p>Favourite sport?</p> 
                <h4 id="2">Football</h4>
                <button  onclick="showAnswer(2)" value="1">Answer</button>
                <p>How old was my brother when I was born?</p> 
                <h4 id="3">3</h4>
                <button  onclick="showAnswer(3)" value="1">Answer</button>
                </div>
        <button id="111" onclick="myFunction()" value="1">Change Stylesheet</button>
                            
        <script>
          //  var myVar = setInterval(myTimer, 1000);

            //function myTimer() 
                var myVar = setInterval(myTimer, 3000);

                function myTimer() {
                var da = new Date();
                document.getElementById("time").innerHTML = da.toLocaleTimeString();
                }
            
                function myFunction()
                      {
                          var link = document.getElementById("123");
                          
                          if (link.href == "file:///C:/Users/hadip/OneDrive/Desktop/DT282/YEAR%203/web%20dev/LAB1/creative.css") {
                              link.href = "file:///C:/Users/hadip/OneDrive/Desktop/DT282/YEAR%203/web%20dev/LAB1/professional.css";
                          }
                          else {
                            link.href = "file:///C:/Users/hadip/OneDrive/Desktop/DT282/YEAR%203/web%20dev/LAB1/creative.css";
                          }
                     }
                
                function imagChange(f)
                {
                    document.getElementById("4").style.border = "none";
                    document.getElementById("5").style.border = "none";
                    document.getElementById("6").style.border = "none";
                    var i = document.getElementById(f);
                    i.style.border = "2px solid white";
                    
                    //alert(i.src);
                    document.getElementById("hadi").src = i.src;
                    //document.getElementById("hadi").src = i;
                }
            function showAnswer(f){
                
                var element = document.getElementById(f);
                if(element.style.display == 'block')
                    element.style.display = 'none';
                else
                    element.style.display = 'block';
                
                
            }
            
            function colorChange()
            {
                //document.getElementById("time").style.backgroundColor =
                var x = Math.floor(Math.random()* 256);
                var y = Math.floor(Math.random()* 256);
                var z = Math.floor(Math.random()* 256);
                document.getElementById("main").style.backgroundColor= "rgb("+x+","+y+","+z+")";
            }
        </script>
		</div>
	</body>
</html>