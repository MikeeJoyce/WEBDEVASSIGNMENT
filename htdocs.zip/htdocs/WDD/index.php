<?php
	echo "Yes!"
?>
