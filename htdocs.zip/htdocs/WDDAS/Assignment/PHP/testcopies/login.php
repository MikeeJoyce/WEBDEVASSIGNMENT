<?php 
	include_once 'header.php';
?>
<body>
    <div class="container" style="margin-top:100px">
        <h1>PUT SHIT HERE</h1>
    </div>

        <h2>Modal Login Form</h2>
</body>


<div id="id01" class="modal">
  
  <form class="login-form animate" action="data/logindb.php" method="post">
    <div class="imgcontainer">
      <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span>
      <img src="img_avatar2.png" alt="Avatar" class="avatar">
    </div>

    <div class="container">
      <label for="luname"><b>Username</b></label>
      <input type="text" placeholder="Enter Username" name="luname" required>

      <label for="lpsw"><b>Password</b></label>
      <input type="password" placeholder="Enter Password" name="lpsw" required>
        
      <button type="submit" name= "loginsubmit">Login</button>
      <label>
        <input type="checkbox" checked="checked" name="remember"> Remember me
      </label>
    </div>
  </form>
</div>

<div id="id02" class="modal">
     <form class="signup-form animate" action="data/signupdb.php" method="POST">

    <div class="container">
        <label for="uname"><b>Username</b></label>
        <input type="text" placeholder="Enter Username" name="uname" required>

        <label for="email"><b>E-mail</b></label>
        <input type="text" placeholder="Enter email address" name="email" required>

        <label for="psw"><b>Password</b></label>
        <input type="password" placeholder="Enter Password" name="psw" required>
        
        <label for="psw"><b>Re-type Password</b></label>
        <input type="password" placeholder="Re-enter Password" name="repsw" required>

        <button type="submit" name="signupsubmit">Signup</button>
        <label>
        <input type="checkbox" checked="checked" name="remember"> Remember me
        </label>
    </div>
  </form>
</div>    

<script>
// Get the modal
var modal = document.getElementById('id01');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>
    
    <?php 
    	include_once 'footer.php';
    ?>