<?php
session_start();
	if (isset($_POST['testsubmit']))
	{
		include_once 'dbconnect.php';
		$ne = $_POST['name_text'];
		
		$quer = "SELECT count(*) FROM JOINT WHERE JOINT.USER = '{$_SESSION['usern']}'";
		$sql = $conn->query($quer);
		$count = $sql->fetchColumn();
		//header("Location: ../login.php?LOGIN=$count");
		if($count == 1 )
		{
		
			$stmt=$conn->prepare("UPDATE JOINT SET GGWP = '$ne' where USER = '{$_SESSION['usern']}';");
			$stmt->execute();
			//$hello = $GLOBALS['username'];
			header("Location: ../TESTER.php?UPDATE=$ne");
			
		}
		
		else 
		header("Location: ../login.php?COUNT=$count");
		
		/*
			header("Location: ../login.php?LOGIN=$user");
 	*/
	}
	
	else 
	{
		header("Location: ../login.php?POST=FAIL");
	}