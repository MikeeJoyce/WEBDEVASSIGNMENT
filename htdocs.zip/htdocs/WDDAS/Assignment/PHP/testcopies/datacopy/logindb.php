<?php
	session_start();
	if(isset($_POST['loginsubmit']))
	{
		include_once 'dbconnect.php';
		//global $usern;
		$_SESSION['usern'] = $_POST['luname'];
		//$GLOBALS['username'] = $usern;
		$passn = $_POST['lpsw'];
		
		if(strcmp($_SESSION['usern'], "Admin") == 0)
		{
			$quer = "SELECT pw from TEST WHERE USER = '{$_SESSION['usern']}'";
			$sql = $conn->query($quer);
			$val = $sql->fetchColumn();
			$verify = password_verify($passn,$val);
			if($verify == 1)
			//{
				header("Location: ../Admin.php?ADMIN=LOGGEDIN");
			//}
			else 
			header("Location: ../login.php?ADMIN=INVALIDPW");
			
		}
	else 
	{
		$quer = "SELECT COUNT(*) from TEST WHERE USER = '{$_SESSION['usern']}'";
		$sql = $conn->query($quer);
		$count = $sql->fetchColumn();
		if($count == 1)
		{
			$quer = "SELECT pw from TEST WHERE USER = '{$_SESSION['usern']}'";
		$sql = $conn->query($quer);
		$val = $sql->fetchColumn();
		//$a = password_hash("123",PASSWORD_DEFAULT);
		//$b = "$2y$10$NtVilY1m9Y5k8gbj/hNdceDg12Hz7vfaX8O0bneXLM.eiDzFBn04.";
		$verify = password_verify($passn,$val);
			if($verify == 1)
			//{
				header("Location: ../TESTER.php?LOGIN=LOGGEDIN");
			//}
			else 
			header("Location: ../login.php?LOGIN=INVALIDPW");
		}
		else 
		{
		//	header("Location: ../login.php?LOGIN=INVALIDUNAME");
		}
	}
	}
	//header("Location: ../login.php?LOGIN=mumgei");
	else 
	header("Location: ../login.php?LOGIN=nogei");
	
	//$usern = $_POST['luname'];
	