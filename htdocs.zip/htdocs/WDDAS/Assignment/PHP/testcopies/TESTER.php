<?php
include_once 'headerli.php'; 
?>
	

	
	<form name="personal_info" id="personal_info" action="data/testdb.php" method="POST">
	
		<td class="name">
		Name:
	</td>
	<td class="data">
		<input type="text" name="name_text"  width="20" maxlength="40" size="20" >
		<button type="submit" name="testsubmit">Signup</button>
        <p id="namemsg"></p>
	</td>
		
	</form>



</html>