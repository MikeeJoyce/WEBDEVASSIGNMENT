<?php
//include_once 'data/dbconnect.php'; 
//echo $_SESSION['$printuser[$c]']. "!!!";
include_once 'headerli.php';

if (isset($_POST['testadminsubmit']))
	{
		include_once 'data/dbconnect.php';
		$_SESSION['chod'] = $_POST['searchvalue'];
		$ne = $_POST['searchvalue'];
			
			$quer = "SELECT * FROM TEST WHERE TEST.USER LIKE '%$ne%'";
		$sql = $conn->query($quer);
		$c = 0;
		$printuser = array();
		$printemail = array();
		$printpw = array();
		
	
		}
	
	
	else 
	{
		header("Location: login.php?POST=FAIL");
	}
	

	?>    
	<script>
	$(document).ready(function()
	{	var counter = 1;
		$("button").click(function()
		{
			counter = counter +1;
			$("#names").load("load-names.php", 
				{
					newCounter: counter 
				});
		});

		});

</script>
    <body>
    <div id = "names">
        <?php 
        $quer = "SELECT * FROM TEST WHERE TEST.USER LIKE '%$ne%' LIMIT 1";
		$sql = $conn->query($quer);
		$c = 0;
		$printuser = array();
		$printemail = array();
		$printpw = array();
		
		while($r = $sql->fetch(PDO::FETCH_ASSOC))
        {  
        	
        	$printuser[$c] = htmlentities($r['USER']);
        	$printemail[$c] = htmlentities($r['EMAIL']);
        	$printpw[$c] = htmlentities($r['REPW']);
        	echo "<br><br><a href=\"resultcv.php?namer=" . $printuser[$c] . "\">" .$printuser[$c] . "</a>";
        	$c++;
        }
        	?>
    </div>
    <button width="20px" >Show More!</button>
    	</body>
    	</html>