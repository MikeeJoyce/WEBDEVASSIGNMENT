<?php
$newCounter = $_POST['newCounter']; 
session_start();
include_once 'data/dbconnect.php';
$quer = "SELECT * FROM TEST WHERE TEST.USER LIKE '%{$_SESSION['chod']}%' LIMIT $newCounter";
		$sql = $conn->query($quer);
		$c = 0;
		$printuser = array();
		$printemail = array();
		$printpw = array();
		
		while($r = $sql->fetch(PDO::FETCH_ASSOC))
        {  
        	
        	$printuser[$c] = htmlentities($r['USER']);
        	$printemail[$c] = htmlentities($r['EMAIL']);
        	$printpw[$c] = htmlentities($r['REPW']);
        	echo "<br><br><a href=\"resultcv.php?namer=" . $printuser[$c] . "\">" .$printuser[$c] . "</a>";
        	$c++;
        }