<?php
include_once 'data/dbconnect.php'; 
include_once 'headerli.php';


        $quer = "SELECT * FROM TEST;";
		$sql = $conn->query($quer);
		
        
       // while($r= $sql->fetch(PDO::FETCH_ASSOC))
       // {
        //	$printuser = htmlentities($r['USER']);
        //	$printemail = htmlentities($r['EMAIL']);
        //	$printpw = htmlentities($r['REPW']);
        //	echo "<br><h3>" . $printuser . " ". $printemail . " " . $printpw . "</h3><br>";
        //}
        
        ?>
        
        <form name="admin_search" id="ads" action="results.php" method="POST">
	
		<td class="name">
		Name:
	</td>
	<td class="data">
		<input type="text" name="searchvalue"  width="20" maxlength="40" size="20" >
		<button type="submit" name="testadminsubmit">Search</button>
        <p id="namemsg"></p>
	</td>
		
	</form>
        
        </body>
</html>  
