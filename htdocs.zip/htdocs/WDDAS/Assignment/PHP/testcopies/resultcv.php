<?php
include_once 'data/dbconnect.php';
include_once 'headerli.php';


if(isset($_GET['namer']))
{
	$namer = $_GET['namer'];
	//echo $namer;
	$_SESSION['value1'] = $namer;
	//exit();
	$quer = "SELECT * FROM TEST WHERE USER = '$namer';";
	$sql = $conn->query($quer);
	
while($r= $sql->fetch(PDO::FETCH_ASSOC))
        {
        	$printuser = htmlentities($r['USER']);
        	$printemail = htmlentities($r['EMAIL']);
        	$printpw = htmlentities($r['REPW']);
        	//echo "tester";
        	echo "<br><h3> Name: " . $printuser . "</h3><br/><h3>Email: ". $printemail . "</h3><br/><h3>Pass:" . $printpw . "</h3><br>";
        }
}




?>
<script>
$(document).ready(function(){	
	$('.button').click(function(){
		var clkBtnVal = $(this).val();
		var ajaxurl = 'ajaxfunction.php',
		data = {'action' : clkBtnVal};
		$.post(ajaxurl, data, function(response){
				
				alert("DONE!");
			});
			
	});
});

</script>
<form id = "mom" action="resultcv.php">

                            <input type="submit" class="button" name="accept" value="Accept"/> 
                        
                        
                            <input type="submit" class="button" name="reject" value="Reject">
                        
</form>

