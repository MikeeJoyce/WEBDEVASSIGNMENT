<?php
session_start();
include_once 'data/dbconnect.php';
include_once 'headerli.php';


if(isset($_GET['name']))
{
	$name = $_GET['name'];
	//echo $name;
	$_SESSION['value1'] = $name;
	//exit();
	$quer = "SELECT * FROM CVDATA WHERE NAME = '$name';";
	$sql = $conn->query($quer);
	
while($r= $sql->fetch(PDO::FETCH_ASSOC))
        {
        	$printsummary = htmlentities($r['SUMMARY']);
			$printexperience = htmlentities($r['EXPERIENCE']);
			$printresponsibility = htmlentities($r['RESPONSIBILITY']);
			$printname = htmlentities($r['NAME']);
			$printdob = htmlentities($r['DOB']);
			$printemail =htmlentities($r['EMAIL']);		
			$printgender = htmlentities($r['GENDER']);
			$printaddress = htmlentities($r['ADDRESS']);
			$printcity = htmlentities($r['CITY']);
			//$printzip = $_POST['zip_text'];
			$category = htmlentities($r['CATEGORY']);
			$employed = htmlentities($r['EMPLOYED']);
			$adult = htmlentities($r['ADULT']);
			$worktime = htmlentities($r['WORKTIME']);
        	//$printuser = htmlentities($r['USERNAME']);
        	//$printemail = htmlentities($r['EMAIL']);
        	//$printpw = htmlentities($r['REPW']);
        	//echo "tester";
        //	echo "<br><h3> Name: " . $printn . "</h3><br/><h3>Email: ". $printemail . "</h3><br/><h3>Pass:" . $printpw . "</h3><br>";
        }
}




?>
<script>
$(document).ready(function(){	
	$('.button').click(function(){
		var clkBtnVal = $(this).val();
		var ajaxurl = 'ajaxfunction.php',
		data = {'action' : clkBtnVal};
		$.post(ajaxurl, data, function(response){
				
				alert("DONE!");
			});
			
	});
});

</script>

<div class="main">
<br><br>
            <header><h1>CURRICULUM VITAE</h1></header>
            <table>
                <tr>
                    <td><?php echo $printname; ?>
                    <br>
                        <?php echo $category; ?><br>
                        <br><br>
                       <i><?php echo $printsummary; ?></i> </td>
                    
                    <td style="text-align=right"><?php echo $printemail; ?><br>
                        <?php echo $printaddress; ?><br>
                        <br>
                        
                </tr>
            </table>
            
            <br><br><hr><br><br>
            <article>
                <h3><b>PERSONAL INFORMATION</b></h3>
                <br>
                <b>DATE OF BIRTH:</b> <?php echo $printdob; ?><br>
                <b>Gender:</b> <?php echo $printgender; ?><br>
                <b>18 OR OLDER?</b> <?php echo $adult; ?><br>
                MAKEUP SOMETHING
            </article>
            <br><br><hr><br><br>
            <article>
                TYPE OF JOB THAT THEY TICKED OR WHATEVA IN THE FORM
            </article>
            <br><br><hr><br><br>
            <article>
                <h3><b>ACHIEVEMENTS</b></h3>
                <i><?php echo $printexperience; ?></i><br>
                <?php echo $printresponsibility; ?>
            </article>
            <br><br><hr><br><br>
            <article>
                <h3><b>WORKTIME</b></h3>
                <?php 
                if(strcmp($worktime, "FT")==0)
                
                echo "Full Time";
				else if(strcmp($worktime, "PT")==0)
                
                echo "Full Time";
				else 
                echo "Temporary Full Time";
				
                ?>
            </article>
            <br><br><hr><br><br>
            
        </div>
<form id = "mom" action="resultcv.php">

                            <input type="submit" class="button" name="accept" value="Accept"/> 
                        
                        
                            <input type="submit" class="button" name="reject" value="Reject">
                        
</form>

