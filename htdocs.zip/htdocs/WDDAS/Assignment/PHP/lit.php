<?php
	session_start(); 
	include_once 'header.php';
?>
<html>
<head>
<title>Form Validation Exercise</title>
<style>
	body{
		font-size: 10pt;
		font-family: Verdana, Helvetica, sans-serif;
		color: #003300;
	}
	h1{
		font-size: 12pt;
		text-align: center;
	}
	p{
		margin: 0px 40px 20px 40px
	}
	td{
		padding: 5px;
	}
	td.name{
		text-align: right;
	}
	td.data{
		text-align: left;
	}
</style>

<script>

	function validateForm(){
		// Insert your form validation code here
    /////////////////////////////////////////////////////////////////////////////1ai
        var x=document.getElementById("personal_info");
        for(var i=0;i<x.elements.length;i++)
        {
            if(x.elements[i].value ==='' && x.elements[i].hasAttribute('required'))
                {
                    alert('Error: you missed a field');
                    return false;
                }
        }
        
////////////////////////////////////////////////////////////////////////////////1aii
        var name = document.getElementById("name_text");
        if(!(name.value.match(/^[a-zA-Z]+$/)))
            {
                 document.getElementById("namemsg").innerHTML = "Invalid! Letters only!";
                return false;
            }
        
////////////////////////////////////////////////////////////////////////////1aiii        
        
        var y=document.getElementById("email_text");
        if(!(y.value.match(/^[\w\-\.\+]+\@[a-zA-Z0-9\.\-]+\.[a-zA-z0-9]{2,4}$/)))
        
        {
            document.getElementById("emailmsg").innerHTML = "Invalid!Enter in the following format: 'letters/characters'@'what mail it is'.'co/com/domain'!";
            return false;
        }        
        
        
        ///////////////////////////////////////////////////////////////////////////1aiv
      
        
        var dobd = document.getElementById("day_text").value;
        var dobm = document.getElementById("month_text").value;
        var doby = document.getElementById("year_text").value;
        var now = new Date();
        var day = now.getDate();
        var month = now.getMonth()+1;
        var year = now.getYear()+1900;
        if((!dobd.match(/^[0-9]+$/))||(!dobm.match(/^[0-9]+$/))||(!doby.match(/^[0-9]+$/)))
           {
                alert("Enter Only in DIGITS!(DD/MM/YYYY)");
                return false;
            }
        else if((dobd>31)||(dobm>12)||(doby>year))
                    {
                        alert("Enter correct date value: Between 0 and 31 for the Day, Between 1 and 12 for Month and before current year, of course!");
                        return false;
                    }
        else 
            {
                if((doby==year)&&(dobm==month)&&(dobd>day))
                    {
                        alert("Write valid day please! You're not born in the future!");
                        return false;
                    }
                
                else if(dobm==2)
                    {
                        if(isLeapYear(doby))
                            {
                                if(dobd>29)
                                    {
                                        alert("Invalid DOB! February only has 29 days in a leap year!!");
                                        return false;
                                    }
                            }
                        else
                            {
                                if(dobd>28)
                                    {
                                        alert("Invalid DOB!Feb only has 28 days in a non leap year!!");
                                        return false;
                                    }
                            }
                    }
                else if(dobm%2==0)
                    {
                        if(dobd>30)
                            {
                               alert("Invalid DOB! This month only has 30 days!!");
                                return false;
                            }
                    }
                
                
            }
        
        
    ////////////////////////////////////////////////////////////////////1avi
    
        
        var city = document.getElementById("city_text");
        if(!(city.value.match(/^[a-zA-Z]+$/)))
            {
                 document.getElementById("citymsg").innerHTML = "Enter only letters for the city name!";
                return false;
            }
            
    /////////////////////////////////////////////////////////////////////////1avii
    
        var zip = document.getElementById("zip_text");
        if(!(zip.value.match(/^[a-zA-Z]+\s[0-9]+$/)))
            
            {
                 document.getElementById("zipmsg").innerHTML = "Invalid Zip Code!!!Enter in the following format: <Letters><space><Digits>!";
                return false;
            }
    
     return true;
	}
    

	function isLeapYear(years){
		return_value = true;
	// There is no leap year if the year is not divisible by 4
		if ((years % 4) != 0)
			return_value = false;

	// There is no leap year if the year is divisible by 100 but not 400
		else if (((years % 100) == 0) && ((year % 400) != 0))
			return_value = false;
		
		return return_value;
	}

</script>
</head>
<body>

<h1>Personal Information</h1>
<form name="personal_info" id="personal_info">
<table align="center" border="0">
<tbody><tr>
	<td class="name">
		Name:
	</td>
	<td class="data">
		<input type="text" name="name_text" id="name_text" width="20" maxlength="40" size="20" required>
        <p id="namemsg"></p>
	</td>
</tr>
<tr>
	<td class="name">
		<?php 
		echo "{$_SESSION['usern']}"?>
	</td>
	<td class="data">
		<input type="text" name="email_text" id="email_text" width="20" maxlength="40" size="20" required>
        <p id="emailmsg"></p>
	</td>
</tr>
<tr>
	<td class="name">
		Date of Birth (DD/MM/YYYY):
	</td>
	<td class="data">
		<input type="text" name="day_text" id="day_text" maxlength="2" size="2" required>/
		<input type="text" name="month_text" id="month_text" maxlength="2" size="2" required>/
		<input type="text" name="year_text" id="year_text" maxlength="4" size="4" required>
        <p id="dobmsg"></p>
	</td>
</tr>
<tr>
	<td class="name">
		Gender:
	</td>
	<td class="data">
		<select name="select_gender" id="select_gender" required>
			<option value="None"></option>
			<option value="F">Female</option>
			<option value="M">Male</option>
		</select>
	</td>
</tr>
<tr>
	<td class="name">
		Street address (line 1):
	</td>
	<td class="data">
		<input type="text" name="addr1_text" id="addr1_text" width="6" size="6" maxlength="5" required>
	</td>
</tr>
<tr>
	<td class="name">
		Street address (line 2):
	</td>
	<td class="data">
		<input type="text" name="addr2_text" id="addr2_text" width="6" size="6" maxlength="5" required>
	</td>
</tr>
<tr>
	<td class="name">
		City:
	</td>
	<td class="data">
		<input type="text" name="city_text" id="city_text" width="6" size="6" maxlength="5" required>
        <p id="citymsg"></p>
	</td>
</tr>
<tr>
	<td class="name">
		ZIP code:
	</td>
	<td class="data">
		<input type="text" name="zip_text" id="zip_text" width="6" size="6" maxlength="5" required>
        <p id="zipmsg"></p>
	</td>
</tr>
<tr>
	<td class="name">
		<input type="button" value="Submit" name="CVsubmit" onclick="validateForm()"> 
	</td>
	<td class="data">
		<input type="reset" value="Clear">
	</td>
</tr>
</tbody></table>
</form>

</body>
</html>