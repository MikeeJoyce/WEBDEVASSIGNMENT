<?php
session_start();
include_once 'data/dbconnect.php'; 
include_once 'headerli.php';


        $quer = "SELECT * FROM TEST;";
		$sql = $conn->query($quer);        
?>
        

        <br><br><br>
        <form name="admin_search" id="ads" action="results.php" method="POST">
	
		<td class="name">
		Select job category:
	</td>
	<td class="data">
		<select name="admin_job" id="admin_job" required>
                                <option value="None"></option>
                                <option value="R">Retail</option>
                                <option value="I">IT</option>
                                <option value="C">Construction/Engineering</option>
                                <option value="M">Marketing</option>
                                <option value="H">Healthcare</option>
                                <option value="W">Work Experience</option>
                                <option value="T">Travel / Tourism</option>
                                <option value="C">Chef jobs</option>
                                <option value="B">Hair and beauty</option>
                                <option value="A">Accountancy</option>
                                <option value="AR">Architecture</option>
                                <option value="HR">HR / Recruitement</option>
                                <option value="V">Voluntary / Charity Work</option>
                            </select>
                            <br><br><br>
		<button type="submit" name="adminsubmit">Search</button>
        <p id="namemsg"></p>
	</td>
		
	</form>
        </body>
</html>  
