<?php
//include_once 'data/dbconnect.php'; 
//echo $_SESSION['$printuser[$c]']. "!!!";
session_start();
include_once 'headerli.php';

if (isset($_POST['adminsubmit']))
	{
		include_once 'data/dbconnect.php';
		$_SESSION['chod'] = $_POST['admin_job'];
		$ne = $_POST['admin_job'];
			
		//	$quer = "SELECT * FROM TEST WHERE TEST.USER LIKE '%$ne%'";
		//$sql = $conn->query($quer);
	
		}
	
	
	else 
	{
		header("Location: login.php?POST=FAIL");
	}
	

	?>    
	<script>
	$(document).ready(function()
	{	var counter = 1;
		$("button").click(function()
		{
			counter = counter +1;
			$("#names").load("load-names.php", 
				{
					newCounter: counter 
				});
		});

		});

</script>

    <body>
        
    <style>

        #names{
            text-align: center;
        }
        
        #names a {
            font-size: 50px;
            transition-duration: 0.4s;
        }
        
        #names a:hover {
            font-size: 60;
            text-decoration: none;
        }
    </style>
        
    <div id = "names">
        <?php 
        $quer = "SELECT * FROM CVDATA WHERE CATEGORY LIKE '%$ne%' LIMIT 1";
		$sql = $conn->query($quer);
		$c = 0;
		$printuser = array();
		
		while($r = $sql->fetch(PDO::FETCH_ASSOC))
        {  
        	
        	$printname[$c] = htmlentities($r['NAME']);
        	echo "<br><br><a href=\"resultcv.php?name=" . $printname[$c] . "\">" .$printname[$c] . "</a>";
        	$c++;
        }
        	?>
    </div><br><br>
    <button width="20px" >Show More!</button>
    	</body>
    	</html>