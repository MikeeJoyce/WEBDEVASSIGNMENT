  <?php 
 	//session_start(); 
 ?>
 <html>
	<header>
	    <head>
	        <title></title>
	        <link rel="stylesheet" type="text/css" href="../css/css.css">
	        <meta charset="utf-8">
	        <meta name="viewport" content="width=device-width, initial-scale=1">
	        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	    </head>
	    
	    <body>
            <style>
                body {
                    margin: auto;
                    height:1500px;
                    margin-top:100px;
                    font-family: microsoft yahei ui light;
                }
        
                form {
                    text-align: center;
                    margin: auto;
                    font-size: 50px;
                }       
                
                button {
                    padding: 50px;
                    font-size: 30px;
                    background-color: white; /* Green */
                    color: black;
                    text-align: center;
                    text-decoration: none;
                    display: inline-block;
                    margin: 4px 2px;
                    -webkit-transition-duration: 0.4s; /* Safari */
                    transition-duration: 0.4s;
                    cursor: pointer;
                }
                
                button:hover {
                    background-color: black;
                    color: white;
                }
                
                
            </style>
	
	    <nav class="navbar navbar-inverse navbar-fixed-top">
	        <div class="container-fluid">
	            <div class="navbar-header">
	                <a class="navbar-brand" href="#">Welcum, <?php echo "{$_SESSION['usern']}";?>!</a>
                    
	            </div>
	            <ul class="nav navbar-nav">
	                <li class="active"><a href="#">Home</a></li>
                    
                    
	               
	                <li onclick="document.getElementById('id02').style.display='block'"style="float:right"><a href="#z">Sign up</a></li>
                    
                    
	                <li><a href="data/logoutdb.php">Log out</a>
                    </li>
	                
	            </ul>
                <?php if(isset($_SESSION['dp']))
                        {
                            echo "<img src=\"data/images/".$_SESSION['dp'].  ".png\"width=\"47px\" height=\"47px\" style=\"float:right; margin-top:1px;border-radius: 50px;\">";
                        }?>
               
	        </div>
	    </nav>
	</header>