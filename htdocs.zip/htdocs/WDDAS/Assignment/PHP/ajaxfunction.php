<?php
session_start();
if(isset($_POST['action'])){
	echo"test";
	archange($_POST['action']);
}
function archange($val)
{
	$alterer = $conn->execute("UPDATE TEST SET AR = '$val' WHERE USER = '{$_SESSION['value1']}';");
	//echo "<br><br><br><br>UPDATED";
	
}