
 
  <html>
	<header>
	    <head>
	        <title></title>
	        <link rel="stylesheet" type="text/css" href="../css/css.css">
	        <meta charset="utf-8">
	        <meta name="viewport" content="width=device-width, initial-scale=1">
	        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	    </head>
	    
	    <body style="height:1500px;margin-top:100px">
	
	    <nav class="navbar navbar-inverse navbar-fixed-top">
	        <div class="container-fluid">
	            <div class="navbar-header">
	                <a class="navbar-brand" href="#">OFCourse.</a>
	            </div>
	            <ul class="nav navbar-nav">
	                <li class="active"><a href="#">Home</a></li>
	                <li onclick="document.getElementById('id02').style.display='block'"style="float:right"><a href="#z">Sign up</a></li>
	                <li onclick="document.getElementById('id01').style.display='block'" style="float:right"><a href="#">Log in</a></li>
	                
	            </ul>
	        </div>
	    </nav>
        </body>
      </header>
</html>