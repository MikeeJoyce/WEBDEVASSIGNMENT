<?php
	if (isset($_POST['signupsubmit']))
	{
		include_once 'dbconnect.php';
		
		$user = mysqli_real_escape_string($conn,$_POST['uname']);
		$email = mysqli_real_escape_string($conn,$_POST['email']);
		$pass = mysqli_real_escape_string($conn,$_POST['psw']);
		$re = mysqli_real_escape_string($conn,$_POST['repsw']);
		$sql= "SELECT * FROM TEST WHERE USER = $user;";
		$result = mysqli_query($conn,$sql);
		$count = mysqli_num_rows($result);
		/*if ($check->rowCount()>0)
		{
			header("Location: ../login.php?LOGIN=usertaken");
			
		}	
		else 
		{
		$stmt->execute();
		
			header("Location: ../login.php?LOGIN=success");
		}*/
		
		$sql= "INSERT INTO TEST (USER,EMAIL,PW,REPW) VALUES($user,$email,$pass,$re)";
		mysqli_query($conn,$sql);
		
		header("Location: ../login.php?LOGIN=$count");
	}
	
	else 
	{
		header("Location: ../login.php?LOGIN=FAIL");
	}