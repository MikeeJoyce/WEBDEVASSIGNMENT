<?php
	if (isset($_POST['signupsubmit']))
	{
		include_once 'dbconnect.php';
		$user = $_POST['uname'];
		$email = $_POST['email'];
		$psw = $_POST['psw'];
		$pass = password_hash($psw,PASSWORD_DEFAULT);
		//$re = $_POST['repsw'];
		$quer = "SELECT count(*) FROM SIGNUPDATA WHERE SIGNUPDATA.USERNAME = '$user';";
		$sql = $conn->query($quer);
		$count = $sql->fetchColumn();
		//header("Location: ../login.php?LOGIN=$count");
		if($count == 0 )
		{
			$stmt=$conn->prepare("INSERT INTO SIGNUPDATA (USERNAME,EMAIL,PASSWORD) VALUES(:user,:email,:pass)");
			$stmt->bindParam(':user',$user);
			$stmt->bindParam(':email',$email);
			$stmt->bindParam(':pass',$pass);
			//$stmt->bindParam(':re',$re);
			$stmt->execute();
			$stmt2=$conn->prepare("INSERT INTO CVDATA(USERNAME)VALUES('$user');");
			$stmt2->execute();
			header("Location: ../login.php?SIGNUP=SUCCESS!");
			
		}
		
		else 
		header("Location: ../login.php?SIGNUP=NO");
		
		/*
			header("Location: ../login.php?LOGIN=$user");
 	*/
	}
	
	else 
	{
		header("Location: ../login.php?SIGNUP=FAIL");
	}