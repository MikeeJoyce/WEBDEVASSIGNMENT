<?php
session_start();

	if (isset($_POST['testadminsubmit']))
	{
		include_once 'dbconnect.php';
		$ne = $_POST['searchvalue'];
		
		//$quer = "SELECT count(*) FROM TEST WHERE TEST.USER = '$ne'";
		//$sql = $conn->query($quer);
		//$count = $sql->fetchColumn();
		//if ($count == 1)
		//{
			//echo "<table style=\"width:100%\"><tr><th>USER</th><th>EMAIL</th><th>PASS</th></tr>";
			
			$quer = "SELECT * FROM TEST WHERE TEST.USER LIKE '%$ne%'";
		$sql = $conn->query($quer);
		$c = 0;
		$printuser = array();
		$printemail = array();
		$printpw = array();
		while($r = $sql->fetch(PDO::FETCH_ASSOC))
        {  
        	
        	$printuser[$c] = htmlentities($r['USER']);
        	$printemail[$c] = htmlentities($r['EMAIL']);
        	$printpw[$c] = htmlentities($r['REPW']);
        	
        	echo $c . "   " . $printuser[$c++] . "<br>";
        	//echo "<td>" . $printuser . "</td><td>". $printemail . "</td><td>" . $printpw . "</td></tr>";
        }
/*
        echo $printuser[0] . "<br>";
        echo $printuser[1] . "<br>";
        echo $printuser[2] . "<br>";
        echo "test";
        echo "momoommo " . count($printuser) . "<br>";
		 $cnt = count($printuser);
		 $_SESSION['pu'] = $printuser;
        for($x = 0; $x < $cnt; $x++)
        {
         echo $_SESSION['pu'][$x] . "<br>";
        }
        
        exit();

        
        
        //for($x = 0; $x < $cnt; $x++)
        //{
        // echo $_SESSION['pu'] . "<br>";
        //}
         $_SESSION['pe'] = $printemail;
         $_SESSION['pp'] = $printpw;
  */     
        //$_SESSION['pu'] = $printuser;  
	 $cnt = count($printuser);
		 $_SESSION['pu'] = $printuser;
      //  for($x = 0; $x < $cnt; $x++)
       // {
        // echo $_SESSION['pu'][$x] . "<br>";
        //}
       // exit();
        header("Location: ../results.php");
		
        //echo "</table></body></html>";
		
		}
	//}
	
	else 
	{
		header("Location: ../login.php?POST=FAIL");
	}