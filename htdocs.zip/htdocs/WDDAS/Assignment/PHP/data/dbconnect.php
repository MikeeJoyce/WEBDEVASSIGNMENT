<?php
$servname = "localhost";
$username = "root";
$password = "";
$dbname = "Assignment";

$conn = new PDO("mysql:host=$servname;dbname=$dbname",$username,$password);
