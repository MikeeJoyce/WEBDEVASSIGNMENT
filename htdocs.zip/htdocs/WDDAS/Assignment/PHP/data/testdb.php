<?php
session_start();
	if (isset($_POST['testsubmit']))
	{
		include_once 'dbconnect.php';
		$quer = "SELECT EMAIL FROM SIGNUPDATA WHERE SIGNUPDATA.USERNAME = '{$_SESSION['usern']}'";
		$sql = $conn->query($quer);
		//$emailid = ;
		//echo $sql->fetchColumn();
		//exit();
		
		$use = $_SESSION['usern']; 
		$summary = $_POST['message'];
		$experience = $_POST['experience'];
		$responsibility = $_POST['responsibility'];
		$name = $_POST['name_text'];
		$dob = $_POST['day_text'] . "/" . $_POST['month_text'] . "/" . $_POST['year_text'];
		$email = $_POST['email_text'];		
		$gender = $_POST['select_gender'];
		$addr1= $_POST['addr1_text'];
		$addr2= $_POST['addr2_text'];
		$address = $addr1 . " , " . $addr2;
		$city = $_POST['city_text'];
		$zip = $_POST['zip_text'];
		$category = $_POST['select_category'];
		$employed = $_POST['employed'];
		$adult = $_POST['adult'];
		$worktime = $_POST['worktime'];
		$crime = $_POST['crime'];
		$crimemessage = $_POST['crimemessage'];
       // $target = "images/".basename($_FILES['file']['name']);
        
        $image = $_FILES['file']['name'];
       // echo $image;
        
        
		
		//exit();
		
		$quer = "SELECT count(*) FROM CVDATA WHERE CVDATA.USERNAME = '{$_SESSION['usern']}'";
		$sql = $conn->query($quer);
		$count = $sql->fetchColumn();
		//echo $count;
		//exit(); 
		//header("Location: ../login.php?LOGIN=$count");
		if($count == 1 )
		{
			//echo "test";
			//exit();
			$stmt=$conn->prepare("UPDATE CVDATA SET NAME = '$name', 
			EMAIL = '$email', DOB = '$dob',GENDER = '$gender',
			ADDRESS = '$address', CITY = '$city', POSTCODE = '$zip', CATEGORY = '$category',
			 EMPLOYED = '$employed', ADULT = '$adult', WORKTIME = '$worktime', CRIME='$crime',
			 CRIMEREASON='$crimemessage',EXPERIENCE = '$experience', 
			RESPONSIBILITY='$responsibility',SUMMARY='$summary', IMAGE='$image' where USERNAME = '{$_SESSION['usern']}';");
			$stmt->execute();
			//$hello = $GLOBALS['username'];
			
			if(move_uploaded_file($_FILES['file']['tmp_name'], "images/" . $use . ".png"))
			{
				header("Location: ../TESTER2.php?UPDATE=DONE");
				
			$msg = "DONE!";
			
			}
			else
				$msg = "nope";
			
			echo $msg;
		}
		
		else 
		header("Location: ../login.php?COUNT=$count");
		
		/*
			header("Location: ../login.php?LOGIN=$user");
 	*/
	}
	
	else 
	{
		header("Location: ../login.php?POST=FAIL");
	}