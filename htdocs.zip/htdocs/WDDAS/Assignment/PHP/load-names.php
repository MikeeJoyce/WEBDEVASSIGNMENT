<?php
$newCounter = $_POST['newCounter']; 
session_start();
include_once 'data/dbconnect.php';
$quer = "SELECT * FROM CVDATA WHERE CATEGORY LIKE '%{$_SESSION['chod']}%' LIMIT $newCounter";
		$sql = $conn->query($quer);
		$c = 0;
		$printuser = array();
		
		while($r = $sql->fetch(PDO::FETCH_ASSOC))
        {  
        	
        	$printname[$c] = htmlentities($r['NAME']);
        	echo "<br><br><a href=\"resultcv.php?name=" . $printname[$c] . "\">" .$printname[$c] . "</a>";
        	$c++;
        }