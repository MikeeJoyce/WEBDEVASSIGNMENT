<?php
if(isset($_GET['namer']))
{
	$namer = $_GET['namer'];
	echo $namer;
	//exit();
	$quer = "SELECT * FROM TEST WHERE USER = '$namer';";
	$sql = $conn->query($quer);
	
while($r= $sql->fetch(PDO::FETCH_ASSOC))
        {
        	$printuser = htmlentities($r['USER']);
        	$printemail = htmlentities($r['EMAIL']);
        	$printpw = htmlentities($r['REPW']);
        	echo "tester";
        	echo "<br><h3> Name: " . $printuser . "</h3><br/><h3>Email: ". $printemail . "</h3><br/><h3>Pass:" . $printpw . "</h3><br>";
        }
}
$value1 = $namer;

function archange($ar)
{
	$alterer = $conn->execute("UPDATE TEST SET AR = '$ar' WHERE USER = '$value1';");
}
